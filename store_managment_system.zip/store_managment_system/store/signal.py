from django.db.models.signals import post_save
from django.contrib.auth.models import User
from django.dispatch import receiver
from .models import *

@receiver(post_save, sender=Item)
def create_init_balance(sender, instance, created, **kwargs):
    
        if created:
            Inventory.objects.create(item=instance,balance=0)

@receiver(post_save, sender=ItemReceivedDetail)
def update_balance_receive(sender, instance, created, **kwargs):
    cb = Inventory.objects.filter(item_id=instance.item_id).first()
    
    if created:
       cb.balance =  cb.balance + instance.quantity
       cb.save()


@receiver(post_save, sender=IssuedModelDetail)
def update_balance_issue(sender, instance, created, **kwargs):
    cb = Inventory.objects.filter(item_id=instance.item_id).first()
    
    if created:
       cb.balance =  cb.balance - instance.quantity
       cb.save()


