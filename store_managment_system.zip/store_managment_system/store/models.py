from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Supplier(models.Model):
      tin = models.IntegerField(verbose_name="Tin No",unique=True,blank=True,null=True,db_index=True)
      title = models.CharField(verbose_name="Supplier Name",max_length=150)
      license_no = models.CharField(verbose_name="License No",max_length=150,null=True,blank=True,unique=True)
      
      def __str__(self):
            
            return f"{self.title}"


class Category(models.Model):
      name = models.CharField(max_length=100,db_index=True,unique=True)
      created = models.DateField(verbose_name="Created Date",auto_now_add=True)
      updated = models.DateField(verbose_name="Created Date",auto_now=True)

      created_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='cat_creator',blank=True,null=True)
      updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='cat_updater',blank=True,null=True)
    

      class Meta:
        verbose_name_plural = 'categories'      


      def __str__(self):
       return self.name


class Item(models.Model):
    category = models.ForeignKey(Category, related_name='item', on_delete=models.CASCADE)
    name = models.CharField(max_length=255,unique=True)
    description = models.TextField(blank=True) 
    inventory_number = models.CharField(verbose_name="Inventory Number", max_length=50,unique=True,blank=True,null=True)
    is_active = models.BooleanField(default=True)
    is_permanent = models.BooleanField(verbose_name="Permatnent",help_text='check if it is permanent otherwise consumer',default=False)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='item_creator',blank=True,null=True)
    updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='item_updater',blank=True,null=True)
    
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name_plural = 'Items'
        ordering = ('-updated',)



    def __str__(self):
        return self.name



class Inventory(models.Model):
    item = models.OneToOneField(Item, related_name='item_balance', on_delete=models.CASCADE)
    balance = models.FloatField()
    
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='inv_creator',blank=True,null=True)
    updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='inv_updater',blank=True,null=True)
    
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    

    def save_model(self, request, obj, form, change):
     if not obj.pk:
        # Only set added_by during the first save.
        obj.created_by = request.user
     super(Inventory,self).save_model(request, obj, form, change)

    class Meta:
        verbose_name_plural = 'Inventories'
        ordering = ('-created',)

    

    def __str__(self):
        return f"{self.item} --- Balance -{self.balance}"
    

#Recieve


class ItemReceived(models.Model):
      
      supplier = models.ForeignKey(Supplier,related_name='item_supplier',null=True,on_delete=models.SET_NULL)   
      received_date =models.DateField(verbose_name="Received Date")
      purchaser = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='item_purchaser',blank=True,null=True)
    
      created = models.DateField(verbose_name="Created Date",auto_now_add=True)
      updated = models.DateField(verbose_name="Updated Date",auto_now=True)
      
      created_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='itemr_creator',blank=True,null=True)
      updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='itemr_updater',blank=True,null=True)
   

      def __str__(self):
            return F"{self.pk}"
      class Meta:
          ordering = ('-id',)
      


class ItemReceivedDetail(models.Model):
      received = models.ForeignKey(ItemReceived,on_delete=models.CASCADE,
                               verbose_name="Received No",related_name='preceived_detail')
      item = models.ForeignKey(Item,on_delete=models.CASCADE,
                               verbose_name="Item",related_name='recevied_itemt')
      quantity =  models.FloatField(verbose_name='Quantity',editable=True)
      unit = models.CharField(verbose_name="Unit",blank=True,null=True,max_length=50)
      price = models.FloatField(verbose_name='Unit Price',null=True)

      created = models.DateField(verbose_name="Created Date",auto_now_add=True)
      updated = models.DateField(verbose_name="Updated Date",auto_now=True)

      created_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='itemrd_creator',blank=True,null=True)
      updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='itemrd_updater',blank=True,null=True)
   




      def __str__(self):
            return F"{self.received}  {self.item}  {self.quantity} {self.price} "



#Issue


class IssuedModel(models.Model):
      
      issue_to = models.ForeignKey(User,related_name='item_issued',null=True,on_delete=models.SET_NULL)   
      issued_date =models.DateField(verbose_name="Issued Date")
     
      created = models.DateField(verbose_name="Created Date",auto_now_add=True)
      updated = models.DateField(verbose_name="Updated Date",auto_now=True)
      
      created_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='issued_by',blank=True,null=True)
      updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='issue_updater',blank=True,null=True)
   

      def __str__(self):
            return F"{self.pk}-{self.issue_to}"
      

class IssuedModelDetail(models.Model):
      
      issued_id = models.ForeignKey(IssuedModel,on_delete=models.CASCADE,
                               verbose_name="Issued Id",related_name='issued_details')
      item = models.ForeignKey(Item,on_delete=models.CASCADE,
                               verbose_name="Item",related_name='issued_item')
      quantity =  models.FloatField(verbose_name='Quantity',editable=True)
      unit = models.CharField(verbose_name="Unit",blank=True,null=True,max_length=50)
      price = models.FloatField(verbose_name='Unit Price',null=True)

      created = models.DateField(verbose_name="Created Date",auto_now_add=True)
      updated = models.DateField(verbose_name="Updated Date",auto_now=True)

      created_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='issued_detail_by',blank=True,null=True)
      updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='issued_detail_updater',blank=True,null=True)
   




      def __str__(self):
            return F"{self.issued_id}  {self.item}  {self.quantity} {self.price} "
