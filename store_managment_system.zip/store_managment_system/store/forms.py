from django  import forms
from .views import *
from .models import *
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Field, Fieldset, Div, HTML, ButtonHolder, Reset, Submit
from django.utils.translation import gettext_lazy as _
from django.forms.models import ModelForm, inlineformset_factory
from .custom_layout_object import *


class AddCategoryForm(forms.ModelForm):

    class Meta:
        model = Category
        fields = ('name',)


class AddSupplierForm(forms.ModelForm):

    class Meta:
        model = Supplier
        fields = ('title',)
        

class AddItemForm(forms.ModelForm):

    class Meta:
        model = Item
        fields = ('category','name','inventory_number','is_active','is_permanent',)


class AddRecieveForm(forms.ModelForm):
    received_date = forms.CharField(widget=forms.TextInput(attrs={
        'type': 'text',
        'class': 'form-control',  
        
        'autocomplete': 'off'
    }))
    class Meta:
        model = ItemReceived
        fields = ('received_date','supplier','purchaser')


    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['purchaser'].queryset = User.objects.filter(is_staff=True)

class AddRecieveDetailForm(forms.ModelForm):

    class Meta:
        model = ItemReceivedDetail
        fields = ('received','item','quantity','price',)




#grn
class ItemReceivedDetailForm(forms.ModelForm):
    
    class Meta:
        model = ItemReceivedDetail
        exclude = ()


ItemReceivedDetailFormSet = inlineformset_factory(
                  ItemReceived,
                  ItemReceivedDetail,
                  form=ItemReceivedDetailForm,
                  fields=['item', 'quantity'],
                  extra=1, can_delete=True
                  )  


class ItemReceivedForm(forms.ModelForm):

    class Meta:
        model = ItemReceived
        exclude = ()


    def __init__(self, *args, **kwargs):
        super(ItemReceivedForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_tag = True
        self.helper.form_class = 'form-horizontal'
        self.helper.label_class = 'col-md-3 create-label'
        self.helper.field_class = 'col-md-9'
        self.helper.layout = Layout(
            Div(
                Field('supplier'),
                HTML("<br>"),
                Field('purchaser'),
                HTML("<br>"),               
                Field('received_date'),
                HTML("<br>"),     
                
                Fieldset('Details',
                    Formset('titles')),                
                 
                ButtonHolder(Submit('submit', '   Submit   ')),
              
                ))
        




#issued



class IssuedDetailForm(forms.ModelForm):
    
    class Meta:
        model = IssuedModelDetail
        exclude = ()

IssuedDetailFormSet = inlineformset_factory(
                  IssuedModel,
                  IssuedModelDetail,
                  form=IssuedDetailForm,
                  fields=['item', 'quantity'],
                  extra=1, can_delete=True
                  )  



class IssuedForm(forms.ModelForm):

    class Meta:
        model = IssuedModel
        exclude = ()


    def __init__(self, *args, **kwargs):
        super(IssuedForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_tag = True
        self.helper.form_class = 'form-horizontal form-row'
        self.helper.label_class = 'col-md-3 create-label'
        self.helper.field_class = 'col-md-9'
        self.helper.layout = Layout(
            Div(
                Field('issue_to'),
                HTML("<br>"),
                Field('issued_date'),
                HTML("<br>"),
                
                HTML("<br>"),
                Fieldset('Add Details',
                    Formset('titles')),                
                 
                ButtonHolder(Submit('submit', '   save   ')),
              
                ))