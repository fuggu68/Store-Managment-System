from django.urls import path
from . import views


app_name='store'

urlpatterns = [
#Supllier
path('supplier/', views.Supllierlist.as_view(), name='supplier_list'),
path('supplier/add/', views.AddSupplier.as_view(), name='add_supplier'),
#Category
path('category/', views.Categorylist.as_view(), name='category_list'),
path('category/add/', views.AddCategory.as_view(), name='add_category'),
# path('category/<int:pk>/', views.CategoryDetailView.as_view(), name='category_detail'),
path('category/update/<int:pk>/', views.UpdateCtegory.as_view(), name='category_update'),
path('category/delete/<int:pk>/', views.CategoryDeleteView.as_view(), name='category_delete'),


path('item/', views.Itemlist.as_view(), name='item_list'),
path('item/add/', views.AddItem.as_view(), name='add_item'),
path('item/update/<int:pk>/', views.UpdateItem.as_view(), name='item_update'),
path('item/delete/<int:pk>/', views.ItemDeleteView.as_view(), name='item_delete'),

path('receved/add/', views.ReceiveCreate.as_view(), name='add_receive'),
path('received_list/', views.ItemReceivedlist.as_view(), name='received_list'),
path('receved_detail/<int:pk>', views.received_detail, name='receive_detail'),
path('received_update/<int:pk>', views.ReceiveUpdate.as_view(), name='received_update'),
path('received_delete/<int:pk>', views.ReceivedDelete.as_view(), name='received_delete'),


#issue

path('issue/add/', views.IssueCreate.as_view(), name='issue_add'),
path('issue_list/', views.Issuelist.as_view(), name='issue_list'),
path('issue_detail/<int:pk>', views.issued_detail, name='issue_detail'),
path('issue_update/<int:pk>', views.IssueUpdate.as_view(), name='issue_update'),
path('issue_delete/<int:pk>', views.IssueDelete.as_view(), name='issue_delete'),

#Report
path('inventory_list/', views.InventoryList.as_view(), name='inventory_list'),
path('receive_report',views.received_report,name='receive_report'),
path('issue_report',views.issued_report, name='issue_report'),
path('fixed_report',views.fixed_asset, name='fixed_report')

]