
from django.shortcuts import get_object_or_404, redirect, render
from . models import *
from . forms import *
from . forms import ItemReceivedDetailFormSet
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic import ListView, DetailView, TemplateView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.urls import reverse
from django.db import transaction
from django.db.models import Sum
# Create your views here.
#Suppllier
class Supllierlist( LoginRequiredMixin, ListView):

    template_name = 'store/category/supplier_list.html'
    model = Supplier


class AddSupplier(LoginRequiredMixin, CreateView):

    template_name = 'store/category/add_supplier.html'
    model = Supplier
    form_class = AddSupplierForm
    

    def get_success_url(self):
        return reverse_lazy('store:supplier_list')
    
#Category

class Categorylist( LoginRequiredMixin, ListView):
    template_name = 'store/category/category_list.html'
    model = Category



class AddCategory(LoginRequiredMixin, CreateView):

    template_name = 'store/category/add_category.html'
    model = Category
    form_class = AddCategoryForm
    

    def get_success_url(self):
        return reverse_lazy('store:category_list')
    
    def form_valid(self, form):
        instance = form.save(commit=False)
        instance.created_by = self.request.user
        instance.save()
        messages.success(
            self.request, "You have successfully added  Category")
        return super().form_valid(form)
    

class UpdateCtegory(LoginRequiredMixin, UpdateView):
    template_name = "store/category/update_cat.html"
   
    model = Category
    form_class = AddCategoryForm
    

    def get_success_url(self):
        return reverse_lazy("store:category_list")

    def form_valid(self, form):
        instance = form.save(commit=False)
        instance.updated_by = self.request.user
        instance.save()
        messages.success(
            self.request, "You have successfully Updated the Category")
        return super(UpdateCtegory, self).form_valid(form)
    

class CategoryDeleteView(LoginRequiredMixin, DeleteView):
    template_name = "store/category/category_delete.html"
    model= Category

    def get_success_url(self):
        return reverse("store:category_list")
    

 #Item
    
class AddItem(LoginRequiredMixin, CreateView):

    template_name = 'store/item/add_item.html'
    model = Item
    form_class = AddItemForm
    
    

    def get_success_url(self):
        return reverse_lazy('store:item_list')
    
    def form_valid(self, form):

        instance = form.save(commit=False)
        instance.created_by = self.request.user
        instance.save()
        messages.success(
            self.request, f"You have successfully added Item")
        return super().form_valid(form)
    

class UpdateItem(LoginRequiredMixin, UpdateView):
    template_name = "store/item/update_item.html"
    form_class = AddItemForm
    model = Item
    

    def get_success_url(self):
        return reverse_lazy("store:item_list")

    def form_valid(self, form):
        instance = form.save(commit=False)
        instance.updated_by = self.request.user
        instance.save()
        messages.success(
            self.request, "You have successfully Updated the Item")
        return super(UpdateItem, self).form_valid(form)

class Itemlist( LoginRequiredMixin, ListView):
    template_name = 'store/item/item_list.html'
    model = Item


class ItemDeleteView(LoginRequiredMixin, DeleteView):
    template_name = "store/category/item_delete.html"
    model= Category

    def get_success_url(self):
        return reverse("store:category_list")



class InventoryList(LoginRequiredMixin, ListView):
    template_name = 'store/item/inventory.html'
    model = Inventory


class ItemReceivedlist( LoginRequiredMixin, ListView):
    template_name = 'store/item/received_list.html'
    model = ItemReceived


    

class ReceiveCreate(LoginRequiredMixin,CreateView):
        
        model = ItemReceived
        template_name = 'store/item/receive_add.html'
        form_class = ItemReceivedForm
        success_url = None
    
    
        def get_context_data(self, **kwargs):
          data = super(ReceiveCreate, self).get_context_data(**kwargs)
          if self.request.POST:
            data['titles'] = ItemReceivedDetailFormSet(self.request.POST)
          else:
            data['titles'] = ItemReceivedDetailFormSet()
          return data

        def form_valid(self, form):
          context = self.get_context_data()
          titles = context['titles']
          with transaction.atomic():
            
            self.object = form.save()
            if titles.is_valid():
                
                titles.instance = self.object
                titles.instance.created_by = self.request.user
                titles.save()
          return super(ReceiveCreate, self).form_valid(form)

        def get_success_url(self):
          return reverse_lazy('store:received_list')
        
#receiv update

class ReceiveUpdate(LoginRequiredMixin, UpdateView):
    template_name = 'store/item/received_update.html'
    #form_class = AddRecieveDetailForm   
    model = ItemReceivedDetail
    fields = ['item','quantity',]   

    def get_success_url(self):
    
        rec_id=ItemReceivedDetail.objects.filter(id=self.kwargs['pk'])
        for rc in rec_id:
            pass
        return reverse("store:receive_detail", kwargs={"pk": rc.received})

    def form_valid(self, form):
        instance = form.save(commit=False)
        instance.updated_by = self.request.user
        instance.save()
        messages.success(
            self.request, "You have successfully Updated the Receive Detail")
        return super(ReceiveUpdate, self).form_valid(form)
        
#Received Detail Delete
class ReceivedDelete(LoginRequiredMixin, DeleteView):
    template_name = "store/item/received_delete.html"
    model = ItemReceivedDetail

    def get_success_url(self):
        rec_id=ItemReceivedDetail.objects.filter(id=self.kwargs['pk'])
        for rc in rec_id:
            pass
        return reverse("store:receive_detail", kwargs={"pk": rc.received})



#issued formset


class IssueCreate(LoginRequiredMixin,CreateView):

        model = IssuedModel
        template_name = 'store/item/issue_add.html'
        form_class = IssuedForm
        success_url = None       
            

    
        def get_context_data(self, **kwargs):
          data = super(IssueCreate, self).get_context_data(**kwargs)
          if self.request.POST:
            data['titles'] = IssuedDetailFormSet(self.request.POST)

            
            # curbal=Inventory.objects.filter(item_id=data.item)
            # curbal.balance
            # if data.quantity < curbal.balance:
            #     return reverse_lazy('store:issue_add')  
                
          else:
            data['titles'] = IssuedDetailFormSet()

          
          return data

        def form_valid(self, form):

          context = self.get_context_data()
          titles = context['titles']
          
          with transaction.atomic():
            
            self.object = form.save()
            if titles.is_valid():
                titles.instance = self.object
                titles.instance.created_by = self.request.user
                titles.save()
          return super(IssueCreate, self).form_valid(form)

        def get_success_url(self):
          return reverse_lazy('store:issue_list')




#Issue update

class IssueUpdate(LoginRequiredMixin, UpdateView):
    template_name = 'store/item/issue_update.html'
    #form_class = AddRecieveDetailForm   
    model = IssuedModelDetail
    fields = ['item','quantity',]   

    def get_success_url(self):
    
        rec_id=IssuedModelDetail.objects.filter(id=self.kwargs['pk'])
        for rc in rec_id:
            pass
        return reverse("store:issue_detail", kwargs={"pk": rc.issued_id})

    def form_valid(self, form):
        instance = form.save(commit=False)
        instance.updated_by = self.request.user
        instance.save()
        messages.success(
            self.request, "You have successfully Updated the Issued Detail")
        return super(IssueUpdate, self).form_valid(form)
        
#Received Detail Delete
class IssueDelete(LoginRequiredMixin, DeleteView):
    template_name = "store/item/issue_delete.html"
    model = IssuedModelDetail

    def get_success_url(self):
        rec_id=IssuedModelDetail.objects.filter(id=self.kwargs['pk'])
        for rc in rec_id:
            pass
        return reverse("store:issue_detail", kwargs={"pk": rc.issued_id})

#issue list

class Issuelist(LoginRequiredMixin, ListView):
    template_name = 'store/item/issue_list.html'
    model = IssuedModel
    


def issued_detail(request ,pk=None):
    issu_id = pk
    detail = IssuedModelDetail.objects.filter(issued_id=issu_id)

    return render (request,'store/item/issue_detail_list.html',{'detail':detail})


def received_detail(request ,pk=None):
    
    detail = ItemReceivedDetail.objects.filter(received=pk)

    return render (request,'store/item/receive_detail_list.html',{'detail':detail})
    

def received_report(request):
    if request.POST:
        from_date = request.POST.get("from_date")
        to_date = request.POST.get("to_date")
        

        context = {
                'receive_report_list': ItemReceivedDetail.objects.filter(created__gte=from_date,created__lte=to_date).values('item__name')
                        .annotate(Sum('quantity')),


                'from_date':  request.POST.get("from_date"),
                'to_date': request.POST.get("to_date"),
        }
    else:
        context = None  
    return render(request,'report/receive_report.html',context)


def issued_report(request):
    if request.POST:
        from_date = request.POST.get("from_date")
        to_date = request.POST.get("to_date")
        

        context = {
                'issue_report_list': IssuedModelDetail.objects.filter(created__gte=from_date,created__lte=to_date).values('item__name')
                        .annotate(Sum('quantity')),


                'from_date':  request.POST.get("from_date"),
                'to_date': request.POST.get("to_date"),
        }
    else:
        context = None              
    

    return render(request,'report/issue_report.html',context)
     

def fixed_asset(request):      

    context = {
                'fixed_asset_list': IssuedModelDetail.objects.filter(item__is_permanent=True),
                
        }
    return render(request,'report/fixed_report.html',context)
     

     

    