from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(Inventory)
admin.site.register(IssuedModel)
admin.site.register(IssuedModelDetail)


@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
     list_display = ['tin','title']
     search_fields = ['title','tin']

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']



@admin.register(Item)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['is_permanent', 'category','name', 'is_active', 'created', 'created_by']
    list_filter = ['is_permanent', 'is_active']
    list_editable = ['is_permanent', 'is_active']
  
    search_fields = ['name']
    autocomplete_fields = ['category']
    list_display_links = ['name', ]



class ItemReceivedDetailsInline(admin.TabularInline):
    model = ItemReceivedDetail
    extra = 1
    autocomplete_fields = ['item_id', 'received_id']
    exclude = ['unit']


@admin.register(ItemReceived)
class ItemReceivedAdmin(admin.ModelAdmin):
    list_display = ['id','supplier','purchaser','received_date']
    search_fields = ['id','supplier','purchaser']
    autocomplete_fields = ['purchaser_id', 'supplier']
    list_per_page = 10


    fieldsets = [
        ('Enter Item Received', {'fields': [ 'supplier','purchaser', 'received_date']}),
        
                
    ]
    
    inlines = [ItemReceivedDetailsInline]
  

class ItemReceivedDetailAdmin(admin.ModelAdmin):
    list_display = ['received_id', 'item_id', 'quantity','price']
    search_fields = ['received_id']
    autocomplete_fields = ['item_id', 'received_id']
