from django.urls import path

from .import views

app_name='pages'

urlpatterns = [
    path('', views.home, name='home'),
    path('about_us/', views.about_us, name='about_us'),
    path('help/', views.help, name='help'),
    # path('faq/', views.faq, name='faq'),
    #path('terms-of-service/', views.terms_of_service, name='terms-of-service'),
    path('contact/', views.contact, name='contact'),
]