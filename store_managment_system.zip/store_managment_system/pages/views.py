from django.shortcuts import render
from django.contrib.auth import get_user_model
from store.models import *
from django.contrib.auth.decorators import login_required

# Create your views here.

User = get_user_model()
@login_required(login_url='/login')
def home(request):
     received = ItemReceived.objects.all()
     issued =IssuedModel.objects.all()
     
    
     context = { 
             'employee': User.objects.filter().exclude(is_superuser=True),
             'received5': ItemReceivedDetail.objects.all().order_by('-id')[:5],
             'issued5': IssuedModelDetail.objects.all().order_by('-id')[:5],
             'categories': Category.objects.all(),
             'items':Item.objects.all(),
             'transaction': Supplier.objects.all(),
         

          }

     return render(request, 'pages/index.html', context)

def about_us(request):
     return render(request, 'pages/about_us.html')

def help(request):
     return render(request, 'pages/help.html')

def contact(request):
     return render(request, 'pages/contact.html')

