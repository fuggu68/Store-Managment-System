from django.urls import path
from django.contrib.auth import views as auth_views
from authentication.forms import EmailValidationOnForgotPassword, EmailSetPassword

from . import views

urlpatterns = [
    path('add_user', views.add_user, name='add_user'),
    path('user_list/', views.user_list, name='user_list'),

    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    
    path('password/', views.change_password, name='change_password'),
    path('password-reset/', auth_views.PasswordResetView.as_view(form_class=EmailValidationOnForgotPassword, template_name="authentication/password-reset.html"), name="reset_password"),

    path('password-reset-message/', auth_views.PasswordResetDoneView.as_view(template_name="authentication/password-reset-message.html"), 
    name="password_reset_done"),

    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(form_class=EmailSetPassword,template_name="authentication/password-reset-confirm.html"), name="password_reset_confirm"),

    path('password-reset-complete/', auth_views.PasswordResetCompleteView.as_view(template_name="authentication/password-reset-complete.html"), name="password_reset_complete"),


]