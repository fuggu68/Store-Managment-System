
from django.forms import ModelForm
# importing default user registration form
from django.contrib.auth.forms import UserCreationForm
# importing built-in user model
from django.contrib.auth.forms import User
from django import forms


from django.contrib.auth.forms import PasswordResetForm, SetPasswordForm




class AddUserForm(UserCreationForm):
    first_name = forms.CharField(widget=forms.TextInput(attrs={
        'type': 'text',
        'class': 'form-control',          
        'placeholder': 'first name'
    }))
    last_name = forms.CharField(widget=forms.TextInput(attrs={
        'type': 'text',
        'class': 'form-control',          
        'placeholder': 'last name'
    }))
    # Styling the username form fields
    username = forms.CharField(widget=forms.TextInput(attrs={
        'type': 'text',
        'class': 'form-control',  
        'name': 'username', 
        'placeholder': 'Username'
    }))

    # Styling the password1 form fields
    password1 = forms.CharField(widget=forms.TextInput(attrs={
        'type': 'password',
        'class': 'form-control',  
        'name': 'password1', 
        'placeholder': 'Password'
    }))

    # Styling the password2 form fields
    password2 = forms.CharField(widget=forms.TextInput(attrs={
        'type': 'password',
        'class': 'form-control',  
        'name': 'password2', 
        'placeholder': 'Retype Password'
    }))
    
    # Making the email field required 
    #email = forms.EmailField(required=True)

    # Styling the email form fields
    email = forms.EmailField(widget=forms.TextInput(attrs={
        'type': 'email',
        'class': 'form-control',  
        'placeholder': 'Email Address'
    }))

    
    
    class Meta:
        model = User
        fields = ['first_name','last_name','username','password1','password2', 'email','is_active','is_staff','is_superuser']

    def clean_email(self):
        email = self.cleaned_data['email']
        duplicate_email = User.objects.filter(email=email).exists()
        print("Email Taken")
        if duplicate_email:
            raise forms.ValidationError("This Email address is already in use.")
        return email
    

   


class EmailValidationOnForgotPassword(PasswordResetForm):
    email = forms.EmailField(label="", widget=forms.TextInput(attrs={
        'type': 'email',
        'class': 'form-control',  
        'placeholder': 'Email Address'
    }))

    def clean_email(self):
        email = self.cleaned_data['email']
        if not User.objects.filter(email__iexact=email, is_active=True).exists():
            raise forms.ValidationError("There is no user registered with the specified email address!")

        return email

class EmailSetPassword(SetPasswordForm):
    # Styling the password1 form fields
    new_password1 = forms.CharField(label="", widget=forms.TextInput(attrs={
        'type': 'password',
        'class': 'form-control',  
        'name': 'new_password1', 
        'placeholder': 'Password'
    }))

    # Styling the password2 form fields
    new_password2 = forms.CharField(label="", widget=forms.TextInput(attrs={
        'type': 'password',
        'class': 'form-control',  
        'name': 'new_password2', 
        'placeholder': 'Retype Password'
    }))




class UserProfileUpdateForm(ModelForm):
    class Meta:
        model = User
        fields = ['email']
        # exclude = ['user']





# # Updating the profile form
# class AuthorProfileUpdateForm(ModelForm):
#     phone_no = forms.CharField(widget=forms.TextInput(attrs={
#         'type': 'phone',
#         'class': 'form-control',        
       
#     }))
#     class Meta:
#         model = Author
#         fields = ['phone_no','photo']