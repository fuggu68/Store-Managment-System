from django.shortcuts import render, redirect, HttpResponse, get_object_or_404, Http404
# importing messages
from django.contrib import messages
# import authentication related stuffs
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.urls import reverse
from django.views.generic import ListView, CreateView, UpdateView
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
#from crm.models import Author
from .forms import AddUserForm

from django.contrib.sites.shortcuts import get_current_site
from django.conf import settings
from django.core.mail import send_mail
from django.template.loader import render_to_string

from .tokens import account_activation_token

# Create your views here.

# Signup view
# Create your views here.
@login_required(login_url="login") 
def add_user(request):
    if request.method == 'POST':
        # fill the form with requested data
        reg_form = AddUserForm(request.POST)

        if reg_form.is_valid():
            instance = reg_form.save(commit=False)
            instance.is_active = True
            instance.save()

            site = get_current_site(request)
            mail_subject = "Thank you websrv.mofed.gov.et"
            message = render_to_string('authentication/send-success-email.html', {
                'user': instance,
                'domain': site.domain,
                              
            })

            to_email = reg_form.cleaned_data.get('email')
            to_list = [to_email]
            from_email = settings.EMAIL_HOST_USER
            send_mail(mail_subject, message, from_email,
                      to_list, fail_silently=False, )
            return redirect('user_list')

    else:
        reg_form = AddUserForm()

    context = {
        'reg_form': reg_form,
    }

    return render(request, 'authentication/add_user.html', context)


@login_required(login_url="/login") 
def user_list(request):
    context = {
       'userlist':User.objects.all().order_by('-date_joined').values()
      }

    return render(request, 'authentication/list_user.html',context)
# Activate account view



# Login view


def login_view(request):
    if request.method == 'POST':
        # Get username
        username = request.POST.get('username')
        # Get password
        password = request.POST.get('password')
        user_check = User.objects.filter(username=username).exists()
        if user_check:
            not_active= User.objects.filter(username=username)
            for a in not_active:
                if a.is_active==False:
                  messages.error(
                       request, f"Oops! You are not active User")
                  return render(request, 'authentication/login.html')
                else:
                # Check authentication  
                    user = authenticate(request, username=username, password=password)
                    # If user exists log them in
                    if user is not None:
                        login(request, user)
                        redirect_url = request.GET.get('next', 'pages:home')
                        return redirect(redirect_url)
                    else:
                        # Show error message
                        messages.error(
                            request, f"Oops! Username or Password is invalid. Please try again.")

                    return render(request, 'authentication/login.html')
        
    return render(request, 'authentication/login.html')
# Logout view


def logout_view(request):
    # call logout method
    logout(request)
    return redirect('login')

#Change password
@login_required(login_url='login')
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important!
            messages.success(request, 'Your password was successfully updated!')
            return redirect('change_password')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'authentication/change_password.html', {
        'form': form
    })
